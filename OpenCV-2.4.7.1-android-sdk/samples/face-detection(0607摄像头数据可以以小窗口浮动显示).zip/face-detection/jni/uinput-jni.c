#include <string.h>
#include <jni.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/input.h>
#include <linux/uinput.h>


// character numbers
#define ASCIISIZE 128				//for table
#define SIZETABLE1 47				//for str1
#define SIZETABLE2 21
#define SIZETABLE3 26
#define SIZETABLE4 6

//---------------------------------------------------
// Log
//---------------------------------------------------
#define JNI_DEBUG

#ifdef JNI_DEBUG

#ifndef LOG_TAG
#define LOG_TAG "JNI_DEBUG"
#endif

#include <android/log.h>

#define LOGE(msg) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, msg)
#define LOGI(msg) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, msg)
#define LOGD(msg) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, msg)

#endif


//static global values start
//将要处理的字符根据规则分成四类
//一，分别是可以直接处理的
//二，需要shift组合按键的
//三，需要capslock的
//四，控制键
//此表的作用是将ASCII码的128个字符映射到这个表中，下标为ASCII值，对应相应的字符
//而表中对应的值是此ASCII码在input.h中定义的键值，或者其小写字母对应的键值，或上档的键值
static unsigned char table[ASCIISIZE]={
KEY_RESERVED, 	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	/*0~7*/
KEY_BACKSPACE,	KEY_TAB,		KEY_ENTER,		KEY_RESERVED,	KEY_RESERVED,	KEY_ENTER,		KEY_RESERVED,	KEY_RESERVED,	/*8~15*/
KEY_RESERVED, 	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	/*16~23*/
KEY_RESERVED, 	KEY_RESERVED,	KEY_RESERVED,	KEY_ESC,		KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	KEY_RESERVED,	/*24~31*/
KEY_SPACE,	  	KEY_1,			KEY_APOSTROPHE,	KEY_3,			KEY_4,			KEY_5,			KEY_7,			KEY_APOSTROPHE,	/*32~39*/
KEY_9,        	KEY_0,			KEY_8,			KEY_EQUAL,		KEY_COMMA,		KEY_MINUS,		KEY_DOT,		KEY_SLASH,		/*40~47*/
KEY_0,        	KEY_1,			KEY_2,			KEY_3,			KEY_4,			KEY_5,			KEY_6,			KEY_7,			/*48~55*/
KEY_8,        	KEY_9,			KEY_SEMICOLON,	KEY_SEMICOLON,	KEY_COMMA,		KEY_EQUAL,		KEY_DOT,		KEY_SLASH,		/*56~63*/
KEY_2,        	KEY_A,			KEY_B,			KEY_C,			KEY_D,			KEY_E,			KEY_F,			KEY_G,			/*64~71*/
KEY_H,        	KEY_I,			KEY_J,			KEY_K,			KEY_L,			KEY_M,			KEY_N,			KEY_O,			/*72~79*/
KEY_P,        	KEY_Q,			KEY_R,			KEY_S,			KEY_T,			KEY_U,			KEY_V,			KEY_W,			/*80~87*/
KEY_X,        	KEY_Y,			KEY_Z,			KEY_LEFTBRACE,	KEY_BACKSLASH,	KEY_RIGHTBRACE,	KEY_6,			KEY_MINUS,		/*88~95*/
KEY_GRAVE,    	KEY_A,			KEY_B,			KEY_C,			KEY_D,			KEY_E,			KEY_F,			KEY_G,			/*96~103*/
KEY_H,		  	KEY_I,			KEY_J,			KEY_K,			KEY_L,			KEY_M,			KEY_N,			KEY_O,			/*104~111*/
KEY_P,		  	KEY_Q,			KEY_R,			KEY_S,			KEY_T,			KEY_U,			KEY_V,			KEY_W,			/*112~119*/
KEY_X,			KEY_Y,			KEY_Z,			KEY_LEFTBRACE,	KEY_BACKSLASH,	KEY_RIGHTBRACE,	KEY_GRAVE,		KEY_DELETE		/*120~127*/
};

//所分的四类ASCII码值，根据在input.h中的键值创建的四个分类，分别对应不同的处理方法:func1-4
static char str1[SIZETABLE1] = "`1234567890-=[]\\;',./abcdefghijklmnopqrstuvwxyz";
static char str2[SIZETABLE2] = "~!@#$%^&*()_+{}|:\"<>?";
static char str3[SIZETABLE3] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
static char str4[SIZETABLE4] = {9/*tab*/, 27/*esc*/,8/*backspace*/,13/*enter*/,32/*space*/,10/*NEW LINE*/};//ASCII

//虚拟出来的用户设备
static struct uinput_user_dev uidev;
// 文件 /dev/uinput
static int fd;
//代表输入事件，赋值结构体，模拟真实输入事件
static struct input_event iev;
//static global values end

//static functions start
//初始化设备
static void init_dev()
{
    int i=0;
    if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0) {
    	exit(EXIT_FAILURE);
    }
    if (ioctl(fd, UI_SET_KEYBIT, BTN_LEFT) < 0) {
    	exit(EXIT_FAILURE);
    }
    if (ioctl(fd, UI_SET_KEYBIT, BTN_RIGHT) < 0) {
    	exit(EXIT_FAILURE);
    }

    /*register mouse event*/
    if (ioctl(fd, UI_SET_EVBIT, EV_REL) < 0) {
    	exit(EXIT_FAILURE);
    }
    if (ioctl(fd, UI_SET_RELBIT, REL_X) < 0) {
    	exit(EXIT_FAILURE);
    }
    if (ioctl(fd, UI_SET_RELBIT, REL_Y) < 0) {
    	exit(EXIT_FAILURE);
    }
    if (ioctl(fd, UI_SET_RELBIT, REL_WHEEL) < 0) {
        exit(EXIT_FAILURE);
    }

    //register all the keys on keyboard,128 keys ,we just use the front 58 characters
    while (i < ASCIISIZE) {
    	if (ioctl(fd, UI_SET_KEYBIT, (KEY_ESC + i)) < 0 ) {
    		exit(EXIT_FAILURE);
    	}
    	i++;
    }

    if (&uidev == NULL) {
    	exit(EXIT_FAILURE);
    }
    memset(&uidev, 0, sizeof(uidev));
    snprintf(uidev.name, UINPUT_MAX_NAME_SIZE, "BTRemoteControl");
    uidev.id.bustype = BUS_USB;
    uidev.id.vendor  = 0x1;
    uidev.id.product = 0x1;
    uidev.id.version = 1;

    //register user device
    if (write(fd, &uidev, sizeof(uidev)) < 0) {
        exit(EXIT_FAILURE);
    }
    //create user device
    if (ioctl(fd, UI_DEV_CREATE) < 0) {
    	exit(EXIT_FAILURE);
    }
}

//打开设备
static void	open_uinput()
{

	//rt5631_mute();
	//__android_log_print(ANDROID_LOG_INFO, "JNI CALL", "rt5631_mute() called in jni.");
	//rt5631_unmute();
	//__android_log_print(ANDROID_LOG_INFO, "JNI CALL", "rt5631_unmute() called in jni");
	//__android_log_print(ANDROID_LOG_INFO, "JNI CALL", "IN OPEN UINPUT FILE HERE");
	fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
	__android_log_print(ANDROID_LOG_INFO, "JNI CALL", "IN OPEN UINPUT FILE  FD = %d" ,fd);
	if (fd < 0){
		LOGD("open_uinput failed！");
		exit(EXIT_FAILURE);
	}else{
		LOGD("open_uinput success！");
	}
	__android_log_print(ANDROID_LOG_INFO, "JNI CALL", "IN OPEN UINPUT FILE SUCCESS FD = %d" ,fd);
}

//字符分四类， 找出其属于哪一类
static char findClass(char c)
{
	char flag='0';
	int i;

	for (i = 0; i < SIZETABLE1; i++) {
		if (c == str1[i]) {
			flag = '1';
			return flag;
		}
	}
	for (i = 0; i < SIZETABLE2; i++) {
		if (c == str2[i]) {
			flag='2';
			return flag;
		}
	}
	for (i = 0; i < SIZETABLE3; i++) {
		if (c == str3[i]) {
			flag = '3';
			return flag;
		}
	}
	for (i = 0;i < SIZETABLE4; i++) {
		if (c == str4[i]) {
			flag = '4';
			return flag;
		}
	}
	return flag;
}

//第一类字符，可以直接输出
static void func1(char c)
{
	//if don't sleep , we can't see the output of the char in the current input TextView
	//usleep(1000*50);
	int kval = table[c];

	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 1;
	iev.code = kval;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_KEY;
	iev.code = kval;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
}
//第二类字符 ，需要用到shift作组合键
static void func2(char c)
{
	//if don't sleep , we can't see the output of the char in the current input TextView
	//usleep(1000*50);
	int kval = table[c];

	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 1;
	iev.code = KEY_LEFTSHIFT;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 1;
	iev.code = kval;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 0;
	iev.code = KEY_LEFTSHIFT;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_KEY;
	iev.code = kval;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
}
//第三类字符	大写字母，用capslock 键
static void func3(char c)
{
	//usleep(1000*50);
	int kval = table[c];

	//按下capslock
	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 1;
	iev.code = KEY_CAPSLOCK;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	//松开capslock
	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 0;
	iev.code = KEY_CAPSLOCK;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
	//完成capslock按键动作

	//按需要输出的字符
	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 1;
	iev.code = kval;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_KEY;
	iev.code = kval;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}


	//还要将capslock 键复位，就是再按一次这个键
	//按下capslock
	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 1;
	iev.code = KEY_CAPSLOCK;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	//松开capslock
	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 0;
	iev.code = KEY_CAPSLOCK;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
	//完成capslock按键动作
}
//第四类字符， 控制字符，如enter, esc, space , backspace ,tab, 目前是直接输出。
//notice : need to be modified
static void func4(char c)
{
	//usleep(1000*50);
	int kval = table[c];

	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.value = 1;		//KEY DOWN
	iev.code = kval;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_KEY;
	iev.code = kval;
	iev.value = 0;		//KEY UP
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
}
//static functions end

//jni interface start , called by java
jint  Java_com_android_bttvbox_BluetoothTVBoxService_openUinput
  (JNIEnv *env, jobject thiz)
{
	__android_log_print(ANDROID_LOG_INFO, ">>>>>>>>>>JNI CALL<<<<<<<<<<", "IN OPEN UINPUT CALL");
	open_uinput();
	init_dev();
	return (jint)fd;
}

void  Java_com_android_bttvbox_JNIMessageConsumer_simulateKey
  (JNIEnv *env, jobject thiz, char c)
{
	//根据字符属于不同的种类调用不同的函数
	switch(findClass(c)){
		case '1':
			func1(c);
			break;
		case '2':
			func2(c);
			break;
		case '3':
			func3(c);
			break;
		case '4':
			func4(c);
			break;
		default:
			__android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "illegal character: %c", c);
	}
	__android_log_print(ANDROID_LOG_ERROR, ">>>>>>>>>>simulateKey<<<<<<<<<<", "----------Keyboard clicked----------");
}

void  Java_com_android_bttvbox_JNIMessageConsumer_simulateMouse
  (JNIEnv *env, jobject thiz, jint x, jint y)
{
	//usleep(1000*2);//I don't know how long is better
	__android_log_print(ANDROID_LOG_ERROR, ">>>>>>>>>>simulateMouse<<<<<<<<<<", "----------mouse moving----------");
	memset(&iev, 0, sizeof(iev));
	iev.type = EV_REL;
	iev.code = REL_X;
	iev.value = x;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_REL;
	iev.code = REL_Y;
	iev.value = y;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
	__android_log_print(ANDROID_LOG_ERROR, ">>>>>>>>>>simulateMouse<<<<<<<<<<", "----------mouse moved----------");
}

void  Java_com_android_bttvbox_JNIMessageConsumer_simulateLMClick
  (JNIEnv *env, jobject thiz, char c)
{
	if(c == 'D'){
		__android_log_print(ANDROID_LOG_ERROR, ">>>>>>>>>>Albert simulateLMClick<<<<<<<<<<", "----------Albert LMB down----------");
		memset(&iev,0,sizeof(iev));
		iev.type = EV_KEY;
		iev.code = BTN_LEFT;
		iev.value = 1;
		if (write(fd, &iev, sizeof(iev)) < 0) {
			exit(EXIT_FAILURE);
		}

		memset(&iev, 0, sizeof(iev));
		iev.type = EV_SYN;
		iev.code = SYN_REPORT;
		iev.value = 0;
		if (write(fd, &iev, sizeof(iev)) < 0) {
			exit(EXIT_FAILURE);
		}
	}else if(c == 'U'){
		__android_log_print(ANDROID_LOG_ERROR, ">>>>>>>>>>Albert simulateLMClick<<<<<<<<<<", "----------Albert LMB up----------");
		memset(&iev, 0, sizeof(iev));
		iev.type = EV_KEY;
		iev.code = BTN_LEFT;
		iev.value = 0;
		if (write(fd, &iev, sizeof(iev)) < 0) {
			exit(EXIT_FAILURE);
		}

		memset(&iev, 0, sizeof(iev));
		iev.type = EV_SYN;
		iev.code = SYN_REPORT;
		iev.value = 0;
		if (write(fd, &iev, sizeof(iev)) < 0) {
			exit(EXIT_FAILURE);
		}
	}
}

void  Java_com_android_bttvbox_JNIMessageConsumer_simulateClick
  (JNIEnv *env, jobject thiz)
{
	//usleep(10000); //sleep 10ms

	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.code = BTN_LEFT;
	iev.value = 1;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_KEY;
	iev.code = BTN_LEFT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
	__android_log_print(ANDROID_LOG_ERROR, ">>>>>>>>>>simulateClick<<<<<<<<<<", "----------mouse clicked----------");
}

jint Java_com_android_bttvbox_BluetoothTVBoxService_closeUinput
  (JNIEnv *env, jobject thiz)
{
    if(ioctl(fd, UI_DEV_DESTROY) < 0) {
        exit(EXIT_FAILURE);
    }
    close(fd);
    return (jint)0;
}

static unsigned char UDLR[4]={KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT};
void  Java_com_android_bttvbox_JNIMessageConsumer_simulateUDLR
  (JNIEnv *env, jobject thiz, jint d)
{
	memset(&iev,0,sizeof(iev));
	iev.type = EV_KEY;
	iev.code = UDLR[d];
	iev.value = 1;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_KEY;
	iev.code = UDLR[d];
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
}

void  Java_com_android_bttvbox_JNIMessageConsumer_simulateWheel
  (JNIEnv *env, jobject thiz, jint y)
{
	memset(&iev,0,sizeof(iev));
	iev.type = EV_REL;
	iev.code = REL_WHEEL;
	iev.value = y;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}

	memset(&iev, 0, sizeof(iev));
	iev.type = EV_SYN;
	iev.code = SYN_REPORT;
	iev.value = 0;
	if (write(fd, &iev, sizeof(iev)) < 0) {
		exit(EXIT_FAILURE);
	}
	__android_log_print(ANDROID_LOG_ERROR, ">>>>>>>>>>simulateWheel<<<<<<<<<<", "----------Wheel y=%d----------",y);
}
//jni interface end
